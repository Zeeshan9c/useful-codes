<?php

namespace FluentForm\App;

use FluentForm\Framework\Foundation\App as AppFacade;

class App extends AppFacade
{
    // ...
}
