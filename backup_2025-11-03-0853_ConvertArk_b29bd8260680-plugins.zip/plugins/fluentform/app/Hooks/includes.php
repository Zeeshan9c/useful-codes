<?php

/*
 * Require any extra files here. For example::
 * require_once "shortcodes.php";
 * require_once "crontasks.php";
 */

/**
 * @var \FluentForm\Framework\Foundation\Application $app
 */

include_once __DIR__ . '/Ajax.php';
