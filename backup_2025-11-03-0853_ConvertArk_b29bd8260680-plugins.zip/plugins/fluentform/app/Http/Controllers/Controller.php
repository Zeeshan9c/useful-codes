<?php

namespace FluentForm\App\Http\Controllers;

use FluentForm\Framework\Http\Controller as BaseController;

abstract class Controller extends BaseController
{
    //
}
