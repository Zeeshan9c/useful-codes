<?php

namespace FluentForm\App\Services\Integrations;

use FluentForm\App\Http\Controllers\IntegrationManagerController;

/**
 * @deprecated deprecated use  FluentForm\App\Http\Controllers\IntegrationManagerController;
 */
abstract class IntegrationManager extends IntegrationManagerController
{

}
