<?php
/**
 * Plugin Name: ConvertArk Custom Blocks
 * Description: A collection of custom Gutenberg blocks (no npm build).
 * Version: 1.0
 * Author: Zeeshan
 */

add_action( 'init', function() {
    $blocks_dir = __DIR__ . '/blocks';
    foreach ( glob( $blocks_dir . '/*', GLOB_ONLYDIR ) as $block_dir ) {
        register_block_type( $block_dir );
    }
});
