(function (blocks, element, blockEditor, components) {
	const { createElement: el, Fragment } = element;
	const { RichText, MediaUpload, URLInputButton, useBlockProps, InspectorControls } = blockEditor;
	const { Button, PanelBody } = components;

	blocks.registerBlockType("convertark/card-block", {
		edit: (props) => {
			const { attributes, setAttributes } = props;
			const { title, text, buttonText, buttonUrl, imageUrl } = attributes;

			const onSelectImage = (media) => {
				setAttributes({ imageUrl: media.url });
			};

			const blockProps = useBlockProps({ className: "convertark-card" });

			return el(
				Fragment,
				null,
				// Sidebar controls
				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{ title: "Button Settings", initialOpen: true },
						el("p", null, "Button Link URL:"),
						el(URLInputButton, {
							url: buttonUrl,
							onChange: (url) => setAttributes({ buttonUrl: url }),
						})
					)
				),

				// Block content
				el(
					"div",
					blockProps,
					// Image uploader
					el(MediaUpload, {
						onSelect: onSelectImage,
						allowedTypes: ["image"],
						render: ({ open }) =>
							el(
								Button,
								{ onClick: open, className: "button button-large" },
								imageUrl ? "Change Image" : "Upload Image"
							),
					}),

					// Image preview
					imageUrl &&
						el("div", { className: "ca_card_image" },
							el("img", {
								src: imageUrl,
								alt: title || "Card Image",
								style: { maxWidth: "100%" },
							})
						),

					// Content section
					el("div", { className: "cs_content_wrap" },
						el(RichText, {
							tagName: "h3",
							value: title,
							onChange: (val) => setAttributes({ title: val }),
							placeholder: "Card Title…",
						}),
						el(RichText, {
							tagName: "p",
							value: text,
							onChange: (val) => setAttributes({ text: val }),
							placeholder: "Card description…",
						}),
						el("div", { className: "wp-block-buttons" },
							el("div", { className: "wp-block-button" },
								el(RichText, {
									tagName: "a",
									className: "wp-block-button__link",
									value: buttonText,
									onChange: (val) => setAttributes({ buttonText: val }),
									placeholder: "Button text…",
									href: buttonUrl || "#",
									allowedFormats: [], // disable inline toolbar link to prevent duplicate <a>
								})
							)
						)
					)
				)
			);
		},

		save: (props) => {
			const { attributes } = props;
			const { title, text, buttonText, buttonUrl, imageUrl } = attributes;
			const blockProps = useBlockProps.save({ className: "convertark-card" });

			return el(
				"div",
				blockProps,

				// Image output
				imageUrl &&
					el("div", { className: "ca_card_image" },
						el("img", { src: imageUrl, alt: title || "Card Image" })
					),

				// Content output
				el("div", { className: "cs_content_wrap" },
					title && el(RichText.Content, { tagName: "h3", value: title }),
					text && el(RichText.Content, { tagName: "p", value: text }),
					buttonText &&
						el("div", { className: "wp-block-buttons" },
							el("div", { className: "wp-block-button" },
								el("a", {
									className: "wp-block-button__link",
									href: buttonUrl || "#",
								}, buttonText)
							)
						)
				)
			);
		},
	});
})(window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components);
