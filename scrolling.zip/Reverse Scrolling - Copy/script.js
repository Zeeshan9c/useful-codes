$(document).ready(function() {
    var isStatic = false; // Track if the position is currently static

    // Function to log the scroll position of the hero section as a percentage
    function logHeroScrollPosition() {
        var $heroSection = $('.hero'); // Get the hero section
        var heroOffsetTop = $heroSection.offset().top; // Get the top offset of the hero section
        var heroHeight = $heroSection.outerHeight(); // Get the height of the hero section
        var scrollTop = $(window).scrollTop(); // Get the vertical scroll position in pixels

        // Calculate the scroll position of the hero section
        var heroScrollPosition = scrollTop - heroOffsetTop; // Scroll position relative to the hero section
        var scrollPercentage = (heroScrollPosition / heroHeight) * 100; // Calculate percentage

        // Log the scroll position as a percentage
        console.log('Hero section scroll position: ' + scrollPercentage.toFixed(2) + '%'); // Log it to the console
        
        // Update the first image column's transform based on scrollPercentage multiplied by 3
        var $firstImageColumn = $('.image-column').first();
        $firstImageColumn.css('transform', 'translateY(' + (scrollPercentage * 3) + '%)'); // Multiply scrollPercentage by 3

        // Update the second image column's transform
        updateSecondImageColumnTransform(scrollPercentage);
        
        // Update the third image column's transform
        updateThirdImageColumnTransform(scrollPercentage);

        // Check if scrollPercentage reaches 66.66% to update image blocks
        if (scrollPercentage >= 66.66 && !isStatic) {
            updateImageBlockPosition(true); // Change position to static
        } else if (scrollPercentage < 66.66 && isStatic) {
            updateImageBlockPosition(false); // Change position back to fixed
        }
    }

    // Function to initialize the transform on page load
    function initializeImageTransforms() {
        // Get all image columns
        var $imageColumns = $('.image-column');

        // Loop through each image column to set the initial transform
        $imageColumns.each(function(index) {
            // Calculate the percentage for each section
            var percentageValue = -100 * (index + 1); // This will set the values to -100%, -200%, -300%, ...

            // Set the transform with the percentage value
            $(this).css('transform', 'translateY(' + percentageValue + '%)');
        });

        // Set the first image column to -0% on page load
        $imageColumns.first().css('transform', 'translateY(-0%)');

        // Also call logHeroScrollPosition to update the transform based on the initial scroll position
        logHeroScrollPosition();
    }

     // Function to update the second image column's transform based on scroll
     function updateSecondImageColumnTransform(scrollPercentage) {
        var $secondImageColumn = $('.image-column').eq(1); // Get the second image column
        var initialTransformValue = -100; // Initial value for the second column
        var newTransformValue = initialTransformValue + scrollPercentage * 3; // Update the value with scrollPercentage

        // Set the new transform value
        $secondImageColumn.css('transform', 'translateY(' + newTransformValue + '%)');
    }

    // Function to update the third image column's transform based on scroll
    function updateThirdImageColumnTransform(scrollPercentage) {
        var $thirdImageColumn = $('.image-column').eq(2); // Get the third image column
        var initialTransformValue = -200; // Initial value for the third column
        var newTransformValue = initialTransformValue + scrollPercentage * 3; // Update the value with scrollPercentage
        
        // Prevent the transform value from exceeding 0%
        if (newTransformValue > 0) {
            newTransformValue = 0; // Cap it at 0%
        }

        // Set the new transform value
        $thirdImageColumn.css('transform', 'translateY(' + newTransformValue + '%)');
    }

     // Function to update the position of all image blocks
     function updateImageBlockPosition(toStatic) {
        $('.image-column').css('position', toStatic ? 'static' : 'fixed'); // Change position based on the argument
        isStatic = toStatic; // Update the static tracking variable
        console.log('Image block positions updated to ' + (toStatic ? 'static.' : 'fixed.')); // Log the change for debugging
    }

    // Initialize image transforms on page load
    initializeImageTransforms();

    // Attach the scroll event listener
    $(window).on('scroll', function() {
        logHeroScrollPosition(); // Call the function to log the scroll position of the hero section on scroll
    });
});
