$(document).ready(function() {
    var isStatic = false; // Track if the position is currently static

    // Function to log the scroll position of the hero section as a percentage
    function logHeroScrollPosition() {
        var $heroSection = $('.hero'); // Get the hero section
        var heroOffsetTop = $heroSection.offset().top; // Get the top offset of the hero section
        var heroHeight = $heroSection.outerHeight(); // Get the height of the hero section
        var scrollTop = $(window).scrollTop(); // Get the vertical scroll position in pixels

        // Calculate the scroll position of the hero section
        var heroScrollPosition = scrollTop - heroOffsetTop; // Scroll position relative to the hero section
        var scrollPercentage = (heroScrollPosition / heroHeight) * 100; // Calculate percentage

        // Log the scroll position as a percentage
        console.log('Hero section scroll position: ' + scrollPercentage.toFixed(2) + '%'); // Log it to the console

        // Update the first image column's height based on scrollPercentage
        var $firstImageColumn = $('.image-column').first();
        var newHeight = Math.min(100, 100 + (scrollPercentage * 3)); // Max limit set to 100%
        $firstImageColumn.css('height', newHeight + '%'); // Adjust height based on scroll percentage

        // Update the second image column's height
        updateSecondImageColumnHeight(scrollPercentage);

        // Update the third image column's height based on scrollPercentage
        updateThirdImageColumnHeight(scrollPercentage);

        // Check if scrollPercentage reaches 66.66% to update image blocks
        if (scrollPercentage >= 66.66 && !isStatic) {
            updateImageBlockPosition(true); // Change position to static
        } else if (scrollPercentage < 66.66 && isStatic) {
            updateImageBlockPosition(false); // Change position back to fixed
        }
    }

    // Function to initialize the transform on page load
    function initializeImageTransforms() {
        // Get all image columns
        var $imageColumns = $('.image-column');

        // Loop through each image column to set the initial height
        $imageColumns.each(function(index) {
            if (index === 0) {
                // Set the first image column to 100% on page load
                $(this).css('height', '100%');
            } else {
                // Set all other image columns to 0%
                $(this).css('height', '0%');
            }
        });

        // Also call logHeroScrollPosition to update the height based on the initial scroll position
        logHeroScrollPosition();
    }

    // Function to update the second image column's height based on scroll
    function updateSecondImageColumnHeight(scrollPercentage) {
        var $secondImageColumn = $('.image-column').eq(1); // Get the second image column
        var initialHeight = 0; // Initial height in percentage (adjust as needed)
        var newHeight = Math.min(100, initialHeight + (scrollPercentage * 3)); // Update height with scrollPercentage, capped at 100%

        // Set the new height value
        $secondImageColumn.css('height', newHeight + '%'); // Update height based on scroll percentage
    }

    // Function to update the third image column's height based on scroll
    function updateThirdImageColumnHeight(scrollPercentage) {
        var $thirdImageColumn = $('.image-column').eq(2); // Get the third image column
        var initialHeight = 0; // Initial height in percentage (adjust as needed)
        var newHeight = 0; // Start at 0% initially

        // Start increasing the height when the scroll percentage reaches 66.66%
        if (scrollPercentage >= 33.33) {
            newHeight = Math.min(100, initialHeight + ((scrollPercentage - 33.33) * 3)); // Update height with scrollPercentage, capped at 100%
        }

        // Set the new height value
        $thirdImageColumn.css('height', newHeight + '%'); // Update height based on scroll percentage
    }

    // Function to update the position of all image blocks
    function updateImageBlockPosition(toStatic) {
        $('.image-column').css('position', toStatic ? 'static' : 'fixed'); // Change position based on the argument
        isStatic = toStatic; // Update the static tracking variable
        console.log('Image block positions updated to ' + (toStatic ? 'static.' : 'fixed.')); // Log the change for debugging
    }

    // Initialize image transforms on page load
    initializeImageTransforms();

    // Attach the scroll event listener
    $(window).on('scroll', function() {
        logHeroScrollPosition(); // Call the function to log the scroll position of the hero section on scroll
    });
});
