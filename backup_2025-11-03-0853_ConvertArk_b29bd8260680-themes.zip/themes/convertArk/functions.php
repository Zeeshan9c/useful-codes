<?php
add_action('wp_enqueue_scripts', function () {
    $css_file = get_stylesheet_directory() . '/assets/css/main.css';
    $js_file = get_stylesheet_directory() . '/assets/js/main.js';

    if (file_exists($css_file)) {
        wp_enqueue_style(
            'child-custom-style',
            get_stylesheet_directory_uri() . '/assets/css/main.css',  // Must be main.css here
            [],
            filemtime($css_file)
        );
    }

    if (file_exists($js_file)) {
        wp_enqueue_script(
            'child-custom-script',
            get_stylesheet_directory_uri() . '/assets/js/main.js',
            [],
            filemtime($js_file),
            true
        );
    }
});

function mytheme_copyright_year() {
    return date('Y');
}
add_shortcode('year', 'mytheme_copyright_year');
