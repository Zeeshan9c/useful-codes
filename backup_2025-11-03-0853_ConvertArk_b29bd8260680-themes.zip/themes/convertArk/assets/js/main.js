document.addEventListener("DOMContentLoaded", function () {

	const sbuttons = document.querySelectorAll(".wp-block-button a");
	sbuttons.forEach((btn) => {
		if (!btn.classList.contains("wp-block-button__link")) {
			btn.classList.add("wp-block-button__link", "wp-element-button");
		}
	});


    // === Scroll class handler ===
    function handleScrollClass() {
        if (window.scrollY >= 10) {
            document.body.classList.add("is_scrolled");
        } else {
            if (!document.body.classList.contains("menu_open")) {
                document.body.classList.remove("is_scrolled");
            }
        }
    }

    window.addEventListener("scroll", handleScrollClass);
    handleScrollClass(); // run on load


    // === Navigation toggle handler ===
    const navButton = document.querySelector(".header_toggle");
    const navContainer = document.querySelector("nav.cs_main_nav");
    const header = document.querySelector("header");

    if (navButton && navContainer && header) {
        // Start hidden
        navContainer.style.overflow = "hidden";
        navContainer.style.transition = "height 0.3s ease";
        navContainer.style.display = "none";
        navContainer.style.height = "0";

        navButton.addEventListener("click", function () {
            const headerHeight = header.offsetHeight;
            const availableHeight = window.innerHeight - headerHeight;

            if (navContainer.classList.contains("is-open")) {
                // --- Close menu ---
                navContainer.classList.remove("is-open");
                navContainer.style.height = "0";

                // Wait for transition to finish before hiding
                navContainer.addEventListener(
                    "transitionend",
                    function hideAfterTransition() {
                        if (!navContainer.classList.contains("is-open")) {
                            navContainer.style.display = "none";
                        }
                        navContainer.removeEventListener("transitionend", hideAfterTransition);
                    }
                );

                document.body.classList.remove("header_toggles");
            } else {
                // --- Open menu ---
                navContainer.classList.add("is-open");
                navContainer.style.display = "block"; // show first so height animates
                navContainer.style.top = headerHeight + "px";

                // Allow browser to register display:block before animating
                requestAnimationFrame(() => {
                    navContainer.style.height = availableHeight + "px";
                });

                document.body.classList.add("header_toggles");
            }
        });

        // Update on resize
        window.addEventListener("resize", function () {
            if (navContainer.classList.contains("is-open")) {
                const headerHeight = header.offsetHeight;
                const availableHeight = window.innerHeight - headerHeight;
                navContainer.style.top = headerHeight + "px";
                navContainer.style.height = availableHeight + "px";
            }
        });
    }

    const buttons = document.querySelectorAll('.cs_main_nav > .wp-block-navigation-item.has-child > button');

    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();

            const dropdown = this.nextElementSibling; // the sibling <ul>
            if (!dropdown) return;

            if (dropdown.style.display === "block") {
                // Close dropdown
                dropdown.style.maxHeight = null;
                setTimeout(() => { dropdown.style.display = "none"; }, 300); // wait for transition
            } else {
                // Open dropdown
                dropdown.style.display = "block";
                dropdown.style.maxHeight = dropdown.scrollHeight + "px";
            }
        });
    });
});
